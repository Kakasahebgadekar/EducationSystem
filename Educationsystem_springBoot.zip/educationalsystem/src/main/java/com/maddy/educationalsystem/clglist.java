package com.maddy.educationalsystem;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.util.ArrayList;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class clglist {
	@PostMapping("addcollege")
	void addCollege(@RequestBody College clg ) {
		System.out.println(clg);
	}
	@PutMapping("acollege")
	College addCollege( ) {
		College c1=new College(1,"anuradha engineering college",80000);

		return c1;
	}


	@GetMapping("collegelist/{city}")
	ArrayList<College> clgs(@PathVariable String city) throws ClassNotFoundException, SQLException{
		
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
		
		Statement statement=connection.createStatement();
		
		String sql="select * from colleges";
		
		ResultSet resultset=statement.executeQuery(sql);

		ArrayList<College> acl=new ArrayList<>();
		while(resultset.next()) {
			int clgid=resultset.getInt(1);
			String clgname=resultset.getString(2);
			int clgfee=resultset.getInt(3);
			College c1=new College(clgid,clgname,clgfee);
			acl.add(c1);
			
			
			
			
		}
		System.out.println("this is college in "+city);
		
		return acl;
	}
}
