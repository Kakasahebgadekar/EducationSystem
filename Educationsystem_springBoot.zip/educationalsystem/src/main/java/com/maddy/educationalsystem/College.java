package com.maddy.educationalsystem;

public class College {
    int id;
	String clgname;
	int clg_fee;
	
	
	public College(int id, String clgname, int clg_fee) {
		super();
		this.id = id;
		this.clgname = clgname;
		this.clg_fee = clg_fee;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getClgname() {
		return clgname;
	}


	public void setClgname(String clgname) {
		this.clgname = clgname;
	}


	public int getClg_fee() {
		return clg_fee;
	}


	public void setClg_fee(int clg_fee) {
		this.clg_fee = clg_fee;
	}


	@Override
	public String toString() {
		return "College [id=" + id + ", clgname=" + clgname + ", clg_fee=" + clg_fee + "]";
	}

	
	
}
